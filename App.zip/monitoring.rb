central_observer = Core::Central.instance
Sensor::Monitor.new(central_observer)